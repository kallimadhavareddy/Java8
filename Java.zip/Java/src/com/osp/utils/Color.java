package com.osp.utils;

public enum Color {
    RED,BLUE,GREEN,ORANGE,YELLOW,PINK
}
