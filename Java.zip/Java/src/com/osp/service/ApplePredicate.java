package com.osp.service;

import data.Apple;

public interface ApplePredicate {
    boolean test(Apple apple);
}
